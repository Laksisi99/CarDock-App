package com.example.cardock;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class registration extends MainActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
    }
}